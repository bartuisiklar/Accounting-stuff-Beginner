//
//  StockViewController.swift
//  Project02
//
//  Created by Bartu Işıklar on 18/05/17.
//  Copyright © 2017 Bartu Işıklar. All rights reserved.
//

import UIKit

class StockViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    // MARK: Properties
    
    @IBOutlet weak var orderButton: UIButton!
    @IBOutlet weak var cancelButton: UIButton!
    @IBOutlet weak var stockTV: UITableView!
    var products = Products()
    
    // Getting total price of chosen products
    @IBOutlet weak var totalLabel: UILabel!
    var total:Float = 0 {
        didSet {
            totalLabel.text = "Total: " + "\(round(total*100)/100)"
            orderButton.isEnabled = true
            cancelButton.isEnabled = true
            // If there isn't any chosen products then the label will disappear
            if total == 0 {
                totalLabel.text = ""
                orderButton.isEnabled = false
                cancelButton.isEnabled = false
            }
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Getting products from tabBarController
        products = (tabBarController as! TabBarViewController).products
        // Initialazing the dataSource and delegate of table
        stockTV.dataSource = self
        stockTV.delegate = self
        stockTV.backgroundColor = UIColor(white: 1, alpha: 0)
        orderButton.isEnabled = false
        cancelButton.isEnabled = false
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: UITableViewDataSource
    
    // Section method
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    // Row numbers method
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return products.stockedProductions.count
    }
    
    // Customized cell method
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // Getting cells of 'Stock' table
        let cell = tableView.dequeueReusableCell(withIdentifier: "Stock", for: indexPath) as! TableViewCell
        // Getting the stocked products
        let stock = products.stockedProductions[indexPath.row]
        var id: String; var name: String; var number:Int; var price: Float
        id = stock.id
        name = stock.name
        number = stock.number
        price = stock.price
        // Setting the labels
        cell.idLabel.text = id
        cell.nameLabel.text = name
        cell.numberLabel.text = "\(number)"
        cell.priceLabel.text = "\(round(price*100)/100)"
        return cell
    }
    
    // MARK: UITableViewDelegate
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

        // If checkmark is check and user wants to cancel that product 
        // then checkmark will unmark and price will reduce
        if tableView.cellForRow(at: indexPath)?.accessoryType == UITableViewCellAccessoryType.checkmark {
            tableView.cellForRow(at: indexPath)?.accessoryType = UITableViewCellAccessoryType.none
            products.stockedProductions[indexPath.row].number += 1
            total -= products.stockedProductions[indexPath.row].price

        }
            
        // If checkmark is unmark and user wants to add that product
        // then checkmark will checked and price will increase
        else {
            tableView.cellForRow(at: indexPath)?.accessoryType = UITableViewCellAccessoryType.checkmark
            products.stockedProductions[indexPath.row].number -= 1
            total += products.stockedProductions[indexPath.row].price
        }
        
        // Reload table whether checkmarks are check or not
        stockTV.reloadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = false
        self.navigationController?.navigationBar.topItem?.title = "Stock"
    }
    
    // MARK: Actions
    
    @IBAction func order(_ sender: UIButton) {
        let myVC = storyboard?.instantiateViewController(withIdentifier: "Basket") as! BasketViewController
        
        // It adds chosen products to baskets then push the 'Basket' storyboard
        for i in 0..<stockTV.visibleCells.count where stockTV.visibleCells[i].accessoryType == .checkmark{
            myVC.basket.append(products.stockedProductions[i])
        }
        myVC.newStockedProductions = products.stockedProductions
        myVC.outOufStock = products.outOufStockProductions
        myVC.total = total
        navigationController?.pushViewController(myVC, animated: true)
    }

    @IBAction func cancel(_ sender: UIButton) {
        
        // Resets the chosen products
        for i in 0..<stockTV.visibleCells.count where stockTV.visibleCells[i].accessoryType == .checkmark{
            stockTV.visibleCells[i].accessoryType = .none
            products.stockedProductions[i].number += 1
        }
        total = 0
        // Reload table whether checkmarks are check or not
        stockTV.reloadData()
    }
}
