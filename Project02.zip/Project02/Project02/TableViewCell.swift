//
//  DiscountTableViewCell.swift
//  Project02
//
//  Created by Bartu Işıklar on 18/05/17.
//  Copyright © 2017 Bartu Işıklar. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    // MARK: Properties
    @IBOutlet weak var idLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var numberLabel: UILabel!
    @IBOutlet weak var priceLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    

}
