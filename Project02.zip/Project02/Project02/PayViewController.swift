//
//  PayViewController.swift
//  Project02
//
//  Created by Bartu Işıklar on 20/05/17.
//  Copyright © 2017 Bartu Işıklar. All rights reserved.
//

import UIKit

class PayViewController: UIViewController {
    
    
    // MARK: Properties
    var newStockedProductions = [String]()
    var basketHistory = [String]()
    var outOfStock = [String]()
    var total: Float = 0
    @IBOutlet weak var totalLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        totalLabel.text = "Total: \(total) TL."
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: Writing data
    
    func writeData(){
        // Stock data initializer = 'id,name,numbers,price,discount\n'
        var data: String = "id,name,numbers,price,discount\n"
        for products in newStockedProductions {
            data.append(products)
        }
        for products in outOfStock {
            data.append(products)
        }
        // File path of stock data
        let stockFilePath = Bundle.main.path(forResource: "data", ofType: "txt")
        
        // Keeping the bought history
        // for particular day, hour and minute
        let date = Date()
        let calendar = Calendar.current
        let year = calendar.component(.year, from: date); let month = calendar.component(.month, from: date);
        let day = calendar.component(.day, from: date)
        let hour = calendar.component(.hour, from: date)
        let min = calendar.component(.minute, from: date)
        var history = "Your  history at \(year)-\(month)-\(day), \(hour):\(min) :\n"
        for products in basketHistory {
            history.append(products)
        }
        // Making the file name by day of order
        let basketFileName = "basket-\(year)-\(month)-\(day)"
        let DocumentDirURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let basketFileURL = DocumentDirURL.appendingPathComponent(basketFileName).appendingPathExtension("txt")
        print("Your  history: " + basketFileURL.path)
        
        // Writing the data
        do {
            var historyText = ""
            let fileMngr = FileManager()
            // If there is another order in same day it appends the order for certain hour and minute
            if fileMngr.fileExists(atPath: basketFileURL.path) {
                historyText = try String(contentsOf: basketFileURL, encoding: String.Encoding.utf8)
            }
            historyText.append(history)
            // Write the order history data
            try historyText.write(to: basketFileURL, atomically: true, encoding: String.Encoding.utf8)
            // Write the new stock data
            try data.write(toFile: stockFilePath!, atomically: true, encoding: String.Encoding.utf8)
            } catch {
            print("Error while writing data: \(error)")
        }
        
    }
    
    // MARK: Actions
    
    @IBAction func pay(_ sender: UIButton) {
        let myVC = storyboard?.instantiateViewController(withIdentifier: "Last") as! LastViewController
        navigationController?.pushViewController(myVC, animated: true)

        // Write the data
        writeData()
      

    }
}
