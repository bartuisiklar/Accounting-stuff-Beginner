//
//  DiscountTableViewController.swift
//  Project02
//
//  Created by Bartu Işıklar on 18/05/17.
//  Copyright © 2017 Bartu Işıklar. All rights reserved.
//

import UIKit

class DiscountTableViewController: UITableViewController {
    
    // MARK: Properties
    var products = Products()

    override func viewDidLoad() {
        super.viewDidLoad()
            
        // Getting products from tabBarController
        products = (tabBarController as! TabBarViewController).products
        

        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: UITableViewDataSource

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return products.discountedProductions.count
    }
    


    // Customizing the cells
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // Getting cells of 'Discount' table
        let cell = tableView.dequeueReusableCell(withIdentifier: "Discount", for: indexPath) as! TableViewCell
        // Getting the data from discountedProducts
        var id: String; var name: String; var number:Int; var price: Float
        let discountedProduct = products.discountedProductions[indexPath.row]
        id = discountedProduct.id
        name = discountedProduct.name
        number = discountedProduct.number
        price = discountedProduct.price
        // Setting the labels
        cell.idLabel.text = id
        cell.nameLabel.text = name
        cell.numberLabel.text = "\(number)"
        cell.priceLabel.text = "\(round(price*100)/100)"
        
        // Configure the cell...
        return cell
    }

    // MARK: NavigationBar
    
    // Customizing the navigationbar 
    // It's in viewWillAppear method because you can easily changing the tabs
    // and avoiding the title complexity
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = false
        self.navigationController?.navigationBar.topItem?.title = "Discount"
    }

}
