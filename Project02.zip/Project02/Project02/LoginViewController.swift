//
//  LoginViewController.swift
//  Project02
//
//  Created by Bartu Işıklar on 18/05/17.
//  Copyright © 2017 Bartu Işıklar. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    
    // MARK: Properties
    
    @IBOutlet weak var usernameTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    @IBOutlet weak var errorLabel: UILabel!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // MARK: NavigationBar
        // Setting the navigationbar style and text font
        self.navigationController?.navigationBar.barStyle = .black
        self.navigationController?.navigationBar.titleTextAttributes = [ NSFontAttributeName: UIFont(name: "HelveticaNeue", size: 20)!]
     
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = true
    }
    
    // MARK: Actions
    
    @IBAction func login(_ sender: UIButton) {
        // If username and password information is correct 
        // then push the 'Tab' storyboard
        if usernameTF.text == "bartu" && passwordTF.text == "123" {
        let myVC = storyboard?.instantiateViewController(withIdentifier: "Tab")
        navigationController?.pushViewController(myVC!, animated: true)
        }
        else {
            // If login informations is wrong then giving an error
            errorLabel.text = "Your informations are wrong.\n Please check again."
        }
    }

}
