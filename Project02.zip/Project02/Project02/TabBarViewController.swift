//
//  TabBarViewController.swift
//  Project02
//
//  Created by Bartu Işıklar on 19/05/17.
//  Copyright © 2017 Bartu Işıklar. All rights reserved.
//

import UIKit

class TabBarViewController: UITabBarController {

    // MARK: Properties
    var products = Products()
    
    // Reading data
    func readData() {
        // File path of data that will read
        let filePath = Bundle.main.path(forResource: "data", ofType: "txt")
        do {
            let fullData = try String(contentsOfFile: filePath!, encoding: String.Encoding.utf8)
            var data = fullData.components(separatedBy: "\n")
            // Removing initialazer of data which is 'id,name,numbers,price,discount'
            data.remove(at: 0)
            // Removing the last item of data which is given for deciding the data is ended or not
            let _ = data.popLast()
            // Getting all data and setting the properties
            for p in data {
                let property = p.components(separatedBy: ",")
                let newProduct: (id: String, name: String, number: Int, price: Float, discount: Int)
                newProduct.id = property[0]
                newProduct.name = property[1]
                newProduct.number = Int(property[2])!
                newProduct.price = Float(property[3])!
                newProduct.discount = Int(property[4])!
                products.productions.append(newProduct)
            }
        } catch {
            print("Error while reading: \(error)")
        }
  
    }
    
    // Divinding the productions such as stocked, discounted, outofStock
    func getProductionLists(){
        for i in 0..<products.productions.count {
            // If there is a discount for an item price will reduced when user is buying it
            if products.productions[i].discount == 1 && products.productions[i].number > 0 {
                products.productions[i].price -= (products.productions[i].price * 18) / 100
                products.discountedProductions.append(products.productions[i])
            }
            if products.productions[i].number > 0 {
                products.stockedProductions.append(products.productions[i])
            }
            else {
                products.outOufStockProductions.append(products.productions[i])
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Reading data
        readData()
        // Getting the list of productions
        getProductionLists()
        self.navigationItem.setHidesBackButton(true, animated: false)
        self.tabBar.barStyle = .black
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
