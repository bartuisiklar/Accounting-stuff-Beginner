//
//  Products.swift
//  Project02
//
//  Created by Bartu Işıklar on 19/05/17.
//  Copyright © 2017 Bartu Işıklar. All rights reserved.
//

import UIKit

class Products: NSObject {
    
    // MARK: Production data divided by properties
    var productions: [(id: String, name: String, number: Int, price: Float, discount: Int)] = []
    var stockedProductions: [(id: String, name: String, number: Int, price: Float, discount: Int)] = []
    var discountedProductions: [(id: String, name: String, number: Int, price: Float, discount: Int)] = []
    var outOufStockProductions: [(id: String, name: String, number: Int, price: Float, discount: Int)] = []

}
