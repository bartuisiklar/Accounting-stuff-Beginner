//
//  BasketViewController.swift
//  Project02
//
//  Created by Bartu Işıklar on 18/05/17.
//  Copyright © 2017 Bartu Işıklar. All rights reserved.
//

import UIKit

class BasketViewController: UIViewController, UITableViewDataSource {
    
    // MARK: Properties
    var newStockedProductions: [(id: String, name: String, number: Int, price: Float, discount: Int)] = []
    var basket: [(id: String, name: String, number: Int, price: Float, discount: Int)] = []
    var outOufStock: [(id: String, name: String, number: Int, price: Float, discount: Int)] = []
    @IBOutlet weak var basketTV: UITableView!
    @IBOutlet weak var totalLabel: UILabel!
    var total:Float = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Initializing the dataSource of table and making it transparent
        basketTV.dataSource = self
        basketTV.backgroundColor = UIColor(white: 1, alpha: 0)
        totalLabel.text = "Total: \(total)"
        self.navigationItem.setHidesBackButton(true, animated: false)

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: UITableViewDataSource
    
    // Row number method
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return basket.count
    }
    // Section method
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    // Customizing the cells
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // Getting cells of 'Basket' table
        let cell = tableView.dequeueReusableCell(withIdentifier: "Basket", for: indexPath) as! TableViewCell
        // Setting the label
        cell.idLabel.text = basket[indexPath.row].id
        cell.nameLabel.text = basket[indexPath.row].name
        cell.numberLabel.text = "\(basket[indexPath.row].number)"
        cell.priceLabel.text = "\(round(basket[indexPath.row].price*100)/100)"
        return cell
    }
    
    // MARK: NavigationBar
    
    // Customizing the navigationbar
    // It's in viewWillAppear method because you can easily changing the tabs
    // and avoiding the title complexity
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = false
        self.navigationItem.title = "Basket"
    }
    
    // MARK: Actions
    
    @IBAction func pay(_ sender: UIButton) {
        let myVC = storyboard?.instantiateViewController(withIdentifier: "Pay") as! PayViewController
        myVC.total = total
        // The products not in the basket
        for products in newStockedProductions {
            // If product has discount then increase the price while writing text data
            if products.discount == 1 {
                myVC.newStockedProductions.append("\(products.id),\(products.name),\(products.number),\(products.price*100/18 / (100/18 - 1)),\(products.discount)\n")
            }
            else {
                myVC.newStockedProductions.append("\(products.id),\(products.name),\(products.number),\(products.price),\(products.discount)\n")
            }
        }
        // The products in basket
        for products in basket {
            myVC.basketHistory.append("\(products.id),\(products.name),\(products.number),\(products.price),\(products.discount)\n")
        }
        // The products which out of stock
        for products in outOufStock {
            myVC.outOfStock.append("\(products.id),\(products.name),\(products.number),\(products.price),\(products.discount)\n")
        }
        
        // then pushing the pop-up view which decide screen that if user buy it or not
        self.addChildViewController(myVC)
        myVC.view.frame = self.view.frame
        self.view.addSubview(myVC.view)
        myVC.didMove(toParentViewController: self)
    }
    
    // Getting back to previous view for updating the basket
    @IBAction func update(_ sender: UIButton) {
        _ = navigationController?.popViewController(animated: true)
    }

}
