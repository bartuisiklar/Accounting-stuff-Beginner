//
//  LastViewController.swift
//  Project02
//
//  Created by Bartu Işıklar on 20/05/17.
//  Copyright © 2017 Bartu Işıklar. All rights reserved.
//

import UIKit

class LastViewController: UIViewController {

    @IBOutlet weak var lastLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.setHidesBackButton(true, animated: false)
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: Actions
    
    @IBAction func back(_ sender: UIButton) {
        let myVC = storyboard?.instantiateViewController(withIdentifier: "Login") as! LoginViewController
        navigationController?.pushViewController(myVC, animated: true)

    }
}
